'use client';

import { useState, useRef } from 'react'; // Eliminé useEffect porque usaremos onGlobeReady
import dynamic from 'next/dynamic';
import { Menu, X, Twitter, Instagram, Linkedin, ArrowRight, Music, Image as ImageIcon, Mic, Video, PenTool, Square, MousePointer2, Move, Hand, FileText } from 'lucide-react';

/* --- IMPORTACIÓN DINÁMICA DEL GLOBO --- */
const GlobeComp = dynamic(() => import('react-globe.gl'), { ssr: false });

/* --- SISTEMA DE DISEÑO NEUMÓRFICO (SOFT UI) --- */
const soft = {
  bg: '#E0E5EC',
  textMain: '#2D3748',
  textBody: '#4A5568',
  flat: { 
    backgroundColor: '#E0E5EC', 
    boxShadow: '9px 9px 16px rgb(163,177,198,0.6), -9px -9px 16px rgba(255,255,255, 0.5)', 
    borderRadius: '40px', 
    border: '1px solid rgba(255,255,255,0.2)' 
  },
  button: { 
    backgroundColor: '#E0E5EC', 
    boxShadow: '8px 8px 16px 0 rgba(163,177,198, 0.6), -8px -8px 16px 0 rgba(255,255,255, 0.8)', 
    borderRadius: '50px', 
    border: '1px solid rgba(255,255,255,0.2)', 
    cursor: 'pointer', 
    transition: 'all 0.2s ease',
    color: '#4A5568',
    fontWeight: '700'
  }
};

/* --- ANIMACIONES CSS --- */
const globalStyles = `
  html { scroll-behavior: smooth; }
  @keyframes float { 0% { transform: translateY(0px); } 50% { transform: translateY(-8px); } 100% { transform: translateY(0px); } }
  .animate-float { animation: float 7s ease-in-out infinite; }
`;

/* --- COMPONENTE TARJETA --- */
const SoftCard = ({ title, subtitle, children, buttonLabel, onClick, delay }: any) => {
  const orangeColor = '#F97316'; 
  return (
    <div className="w-full md:w-[400px] p-4 animate-float" style={{ animationDelay: delay }}>
      <div className="flex flex-col justify-between h-[520px] p-8 transition-transform hover:-translate-y-2" style={soft.flat}>
        <div className="mt-2">
            <h3 style={{ fontFamily: 'Avenir, sans-serif', color: soft.textMain }} className="text-3xl font-light leading-none mb-6">
              {title}<br/><span style={{fontWeight: 700}}>{subtitle}</span>
            </h3>
            <div className="w-24 h-1.5 rounded-full mb-8" style={{ backgroundColor: orangeColor }}></div>
            <div style={{ fontFamily: 'Avenir, sans-serif', color: soft.textBody }} className="text-lg font-normal leading-relaxed">
              {children}
            </div>
        </div>
        <button onClick={onClick} className="w-full py-5 rounded-full font-bold tracking-[0.15em] uppercase text-sm text-center mt-auto active:scale-95 hover:shadow-lg transition-all text-white" style={{ backgroundColor: orangeColor, boxShadow: `0 10px 20px -10px ${orangeColor}90` }}>
          <span>{buttonLabel}</span>
        </button>
      </div>
    </div>
  );
};

/* --- MODAL --- */
const StoryModal = ({ isOpen, onClose, mode }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-white/90 backdrop-blur-md p-4">
        <div className="max-w-lg text-center">
            <h2 className="text-4xl font-light text-gray-800 mb-4">Módulo de {mode}</h2>
            <button onClick={onClose} className="px-8 py-3 bg-orange-500 text-white rounded-full font-bold">Cerrar Demo</button>
        </div>
    </div>
  );
};

/* --- PÁGINA PRINCIPAL --- */
export default function Home() {
  const [modalMode, setModalMode] = useState<any>(null);
  const globeEl = useRef<any>();

  // --- ARREGLO DEL SCROLL ---
  // Esta función se ejecuta AHORA SÍ cuando el globo está 100% listo.
  const handleGlobeReady = () => {
    if (globeEl.current) {
      const controls = globeEl.current.controls();
      controls.enableZoom = false; // ESTO LIBERA LA RUEDA DEL MOUSE
      controls.autoRotate = true;
      controls.autoRotateSpeed = 0.5;
    }
  };

  const stories = [
    { lat: -33.4489, lng: -70.6693, label: "Santiago" },
    { lat: 40.7128, lng: -74.0060, label: "New York" },
    { lat: 48.8566, lng: 2.3522, label: "Paris" },
    { lat: 35.6762, lng: 139.6503, label: "Tokyo" }
  ];

  return (
    <main className="min-h-screen font-sans overflow-x-hidden relative" style={{ backgroundColor: soft.bg }}>
      <style jsx global>{globalStyles}</style>
      <StoryModal isOpen={modalMode !== null} mode={modalMode} onClose={() => setModalMode(null)} />
      
      {/* --- HEADER --- */}
      <header className="fixed top-0 left-0 w-full z-[100] flex items-center justify-between px-6 md:px-12 h-32 transition-all bg-[#E0E5EC]/70 backdrop-blur-lg border-b border-white/20">
        <div className="flex items-center">
            <img src="/logo.png" alt="AlmaMundi" className="h-24 w-auto object-contain select-none" />
        </div>
        <nav style={{ fontFamily: 'Avenir, sans-serif' }} className="hidden md:flex gap-8 text-xs font-bold text-gray-600 items-center tracking-widest uppercase">
            {['Manifiesto', 'Historias', 'Mapa'].map((item) => ( 
              <a key={item} href={`#${item.toLowerCase()}`} className="px-8 py-4 active:scale-95 transition-all hover:text-orange-600" style={soft.button}>{item}</a> 
            ))}
        </nav>
      </header>

      {/* --- SECCIÓN 1: MANIFIESTO --- */}
      <section id="manifiesto" className="pt-48 md:pt-64 pb-24 px-6 relative z-10 flex flex-col items-center text-center">
        <div className="max-w-6xl animate-float">
            <h1 style={{ fontFamily: 'Avenir, sans-serif', color: soft.textMain }} className="text-4xl md:text-6xl font-light leading-tight mb-10">
                AlmaMundi es el lugar donde tus historias no se pierden en el scroll, sino que <span className="font-semibold">despiertan otras historias.</span>
            </h1>
            <div className="w-32 h-2 rounded-full mx-auto mb-12 opacity-50 bg-orange-400"></div>
            <p style={{ fontFamily: 'Avenir, sans-serif', color: soft.textBody }} className="text-xl md:text-3xl font-light max-w-4xl mx-auto leading-relaxed">
                Aquí, cada relato importa. <strong>Cada historia es extraordinaria.</strong>
            </p>
        </div>
      </section>
      
      {/* --- SECCIÓN 2: TARJETAS --- */}
      <section id="historias" className="w-full px-6 mb-32 flex flex-col md:flex-row gap-10 justify-center items-center relative z-10">
        <SoftCard title="Tu historia," subtitle="en primer plano" buttonLabel="GRABA TU VIDEO" onClick={() => setModalMode('Video')} delay="0s">
            A veces, una mirada lo dice todo. Anímate a <strong>grabar ese momento que te marcó</strong>, una experiencia que viviste o que alguien más te contó.
        </SoftCard>
        <SoftCard title="Dale voz" subtitle="a tu recuerdo" buttonLabel="GRABA TU AUDIO" onClick={() => setModalMode('Audio')} delay="0.2s">
            Hay historias que se sienten mejor cuando solo se escuchan. <strong>Graba tu relato en audio</strong> y deja que tu voz haga el resto.
        </SoftCard>
        <SoftCard title="Ponle palabras" subtitle="a tu historia" buttonLabel="ESCRIBE TU HISTORIA" onClick={() => setModalMode('Texto')} delay="0.4s">
            Si lo tuyo es escribir, este es tu lugar. Tómate un respiro y <strong>cuenta tu historia a tu ritmo</strong>, palabra por palabra.
        </SoftCard>
      </section>

      {/* --- SECCIÓN 3: EL MAPA --- */}
      <section id="mapa" className="relative w-full min-h-[1100px] flex flex-col justify-start overflow-hidden" 
               style={{ background: 'linear-gradient(to bottom, #E0E5EC 0%, #1A202C 20%, #0F172A 100%)' }}>
        
        <div className="relative z-20 container mx-auto px-6 pt-32 pb-10 flex flex-col items-center text-center">
            <h2 className="text-6xl md:text-8xl font-light mb-8 drop-shadow-xl" style={{ fontFamily: 'Avenir, sans-serif', color: '#F97316' }}>
                Mapa de AlmaMundi
            </h2>
            <p className="text-gray-300 text-xl max-w-2xl font-light leading-relaxed mb-12">
                Un tejido vivo de memoria humana. <br/>Cuando miles compartan, este mundo brillará.
            </p>

            <div className="inline-flex flex-wrap justify-center gap-6 md:gap-10 p-6 rounded-full border border-white/10 bg-white/5 backdrop-blur-md">
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center"><MousePointer2 size={16} /></div>
                    <span className="text-xs text-gray-300 uppercase tracking-widest">Gira (Clic)</span>
                </div>
                <div className="w-px h-8 bg-white/10"></div>
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center"><Hand size={16} /></div>
                    <span className="text-xs text-gray-300 uppercase tracking-widest">Toca Puntos</span>
                </div>
            </div>
        </div>

        {/* GLOBO 3D */}
        <div className="w-full h-[900px] flex items-center justify-center cursor-move relative z-10 -mt-20">
             <GlobeComp 
                ref={globeEl}
                onGlobeReady={handleGlobeReady} // <--- ESTA ES LA CLAVE DEL ARREGLO
                globeImageUrl="/mapa-mundi.jpg" 
                backgroundColor="rgba(0,0,0,0)" 
                pointsData={stories}
                pointLat="lat"
                pointLng="lng"
                pointColor={() => "#F97316"} 
                pointAltitude={0} 
                pointRadius={0.4} 
                height={900}
                width={900}
            />
        </div>
        <div className="h-32 w-full"></div>
      </section>
    </main>
  );
}